import { useState } from "react";

/* ─── DATA ─────────────────────────────────────────────── */
const roleConfig = {
  Student: {
    badge: "🎓 Student Portal",
    label: "student",
    features: [
      ["📋", "Submit grievances with category & priority"],
      ["🔍", "Track status using your unique token ID"],
      ["📜", "View personal history & resolution timeline"],
      ["📤", "Export own grievances as CSV"],
    ],
  },
  Admin: {
    badge: "🛡️ Admin Portal",
    label: "admin",
    features: [
      ["⚙️", "View & manage all grievances system-wide"],
      ["👮", "Assign grievances to officers"],
      ["⚖️", "Escalate to Level 2 or Level 3"],
      ["📊", "Access analytics dashboard & CSV export"],
    ],
  },
  Officer: {
    badge: "⚙️ Officer Portal",
    label: "officer",
    features: [
      ["📋", "View all assigned grievances"],
      ["✅", "Update status and add resolution notes"],
      ["🔍", "Review case details and audit trail"],
      ["💬", "Communicate resolution details"],
    ],
  },
  credentials: {
    badge: "🔐 Signing In",
    label: "login",
    features: [
      ["🎓", "Student login — submit & track grievances"],
      ["🛡️", "Admin login — full system access"],
      ["⚙️", "Officer login — review & resolve cases"],
      ["🔒", "Secure, role-based access control"],
    ],
  },
};

/* ─── CSS (injected once) ───────────────────────────────── */
const CSS = `
@import url('https://fonts.googleapis.com/css2?family=EB+Garamond:ital,wght@0,400;0,500;0,600;0,700;1,400&family=DM+Sans:wght@300;400;500;600&display=swap');

*, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

.sgr-root[data-theme="dark"] {
  --bg: #0a0c14; --surface: #0f1120; --card: #131626; --card-hover: #171a2e;
  --border: rgba(255,255,255,0.08); --border-glow: rgba(79,109,180,0.45);
  --accent: #4f6db4; --accent2: #7b9dd4; --accent3: #4caf85;
  --text: #e8eaf2; --text-heading: #f0f2ff; --muted: #7a7f9a; --dim: #3e4260;
  --nav-bg: rgba(10,12,20,0.88); --cta-bg: rgba(79,109,180,0.12);
  --cta-border: rgba(79,109,180,0.28); --rule-color: rgba(255,255,255,0.06);
  --stat-bg: #0f1120; --toggle-bg: #1a1d2e; --toggle-border: rgba(255,255,255,0.12);
  --shadow: 0 4px 24px rgba(0,0,0,0.4); --orb-opacity: 0.12;
}
.sgr-root[data-theme="light"] {
  --bg: #f5f6fa; --surface: #eceef6; --card: #ffffff; --card-hover: #f8f9ff;
  --border: rgba(0,0,0,0.08); --border-glow: rgba(50,80,160,0.3);
  --accent: #2d4fa0; --accent2: #4a72c4; --accent3: #2a8c65;
  --text: #1e2140; --text-heading: #0f1230; --muted: #5a5f7a; --dim: #9094b0;
  --nav-bg: rgba(245,246,250,0.92); --cta-bg: rgba(45,79,160,0.06);
  --cta-border: rgba(45,79,160,0.2); --rule-color: rgba(0,0,0,0.07);
  --stat-bg: #eceef6; --toggle-bg: #e4e6f0; --toggle-border: rgba(0,0,0,0.1);
  --shadow: 0 4px 24px rgba(0,0,0,0.08); --orb-opacity: 0.06;
}

.sgr-root {
  font-family: 'DM Sans', sans-serif;
  background: var(--bg); color: var(--text);
  min-height: 100vh; overflow-x: hidden;
  transition: background 0.3s, color 0.3s;
}

/* ORBS */
.bg-orbs { position: fixed; inset: 0; pointer-events: none; z-index: 0; overflow: hidden; }
.orb { position: absolute; border-radius: 50%; filter: blur(130px); opacity: var(--orb-opacity); transition: opacity 0.4s; }
.orb-1 { width: 700px; height: 700px; background: #3a5aa0; top: -250px; left: -150px; animation: drift1 18s ease-in-out infinite alternate; }
.orb-2 { width: 600px; height: 600px; background: #6080b8; bottom: -200px; right: -150px; animation: drift2 22s ease-in-out infinite alternate; }
.orb-3 { width: 350px; height: 350px; background: #2a7a60; top: 45%; left: 55%; animation: drift3 15s ease-in-out infinite alternate; }
@keyframes drift1 { from { transform: translate(0,0); } to { transform: translate(50px,35px); } }
@keyframes drift2 { from { transform: translate(0,0); } to { transform: translate(-40px,-50px); } }
@keyframes drift3 { from { transform: translate(0,0); } to { transform: translate(25px,-35px); } }

/* NAV */
.sgr-nav {
  position: fixed; top: 0; left: 0; right: 0; z-index: 100;
  display: flex; align-items: center; justify-content: space-between;
  padding: 0 3rem; height: 64px;
  background: var(--nav-bg); backdrop-filter: blur(24px);
  border-bottom: 1px solid var(--border);
  transition: background 0.3s, border-color 0.3s;
}
.nav-left { display: flex; align-items: center; gap: 2rem; }
.nav-brand {
  display: flex; align-items: center; gap: 0.6rem;
  font-family: 'EB Garamond', serif; font-weight: 600;
  font-size: 1.1rem; color: var(--text-heading); letter-spacing: 0.01em;
  text-decoration: none; cursor: pointer;
}
.brand-emblem {
  width: 28px; height: 28px; border-radius: 6px;
  background: var(--accent);
  display: flex; align-items: center; justify-content: center;
}
.brand-emblem svg { width: 14px; height: 14px; stroke: #fff; fill: none; stroke-width: 2.5; }
.nav-divider { width: 1px; height: 22px; background: var(--border); }
.nav-subtitle { font-size: 0.72rem; color: var(--muted); letter-spacing: 0.04em; text-transform: uppercase; font-family: 'DM Sans', sans-serif; }
.nav-links { display: flex; align-items: center; gap: 2.2rem; list-style: none; }
.nav-links a { text-decoration: none; color: var(--muted); font-size: 0.82rem; font-weight: 500; transition: color 0.2s; letter-spacing: 0.01em; cursor: pointer; }
.nav-links a:hover { color: var(--text); }
.nav-right { display: flex; align-items: center; gap: 1rem; }

/* THEME TOGGLE */
.theme-toggle {
  width: 52px; height: 28px; border-radius: 100px;
  background: var(--toggle-bg); border: 1px solid var(--toggle-border);
  cursor: pointer; position: relative; transition: all 0.3s; flex-shrink: 0;
}
.theme-toggle-knob {
  position: absolute; top: 3px; left: 3px;
  width: 20px; height: 20px; border-radius: 50%;
  background: var(--accent); transition: transform 0.3s, background 0.3s;
  display: flex; align-items: center; justify-content: center;
}
.theme-toggle-knob.light { transform: translateX(24px); }
.theme-toggle-knob svg { width: 11px; height: 11px; stroke: #fff; fill: none; stroke-width: 2; }

.btn-nav {
  background: var(--accent); color: #fff; border: none;
  padding: 0.5rem 1.4rem; border-radius: 6px;
  font-family: 'DM Sans', sans-serif; font-size: 0.82rem; font-weight: 600;
  cursor: pointer; transition: background 0.2s, transform 0.15s, box-shadow 0.2s;
  letter-spacing: 0.02em;
}
.btn-nav:hover { background: var(--accent2); transform: translateY(-1px); box-shadow: 0 4px 16px rgba(79,109,180,0.35); }

/* HERO */
.hero {
  position: relative; z-index: 2;
  min-height: 100vh;
  display: flex; flex-direction: column; align-items: center; justify-content: center;
  text-align: center; padding: 8rem 2rem 5rem;
}
.hero-title {
  font-family: 'EB Garamond', serif;
  font-size: clamp(2.6rem, 5.5vw, 5rem);
  font-weight: 600; line-height: 1.1;
  letter-spacing: -0.01em; max-width: 820px;
  color: var(--text-heading);
  animation: fadeUp 0.5s 0.08s ease both;
}
.hero-title .highlight {
  font-style: italic;
  background: linear-gradient(135deg, var(--accent), var(--accent2));
  -webkit-background-clip: text; -webkit-text-fill-color: transparent;
  background-clip: text;
}
.hero-sub {
  margin-top: 1.6rem; font-size: 1rem; color: var(--muted);
  max-width: 540px; line-height: 1.8; font-weight: 400;
  animation: fadeUp 0.5s 0.16s ease both;
}
.hero-cta {
  margin-top: 2.5rem; display: flex; gap: 1rem;
  flex-wrap: wrap; justify-content: center;
  animation: fadeUp 0.5s 0.24s ease both;
}
.btn-primary {
  background: var(--accent); color: #fff; border: none;
  padding: 0.82rem 2.1rem; border-radius: 6px;
  font-family: 'DM Sans', sans-serif; font-size: 0.9rem; font-weight: 600;
  cursor: pointer; transition: all 0.2s;
  box-shadow: 0 0 24px rgba(79,109,180,0.3);
  display: inline-flex; align-items: center; gap: 0.5rem;
  letter-spacing: 0.02em;
}
.btn-primary:hover { background: var(--accent2); transform: translateY(-2px); box-shadow: 0 8px 28px rgba(79,109,180,0.45); }
.btn-outline {
  background: transparent; color: var(--text);
  border: 1px solid var(--border);
  padding: 0.82rem 1.9rem; border-radius: 6px;
  font-family: 'DM Sans', sans-serif; font-size: 0.9rem; font-weight: 500;
  cursor: pointer; transition: all 0.2s;
  display: inline-flex; align-items: center; gap: 0.5rem;
}
.btn-outline:hover { border-color: var(--border-glow); background: rgba(79,109,180,0.05); }

/* STATS BAR */
.stats-bar {
  margin-top: 4rem; display: flex; gap: 0;
  border: 1px solid var(--border); border-radius: 8px;
  overflow: hidden; background: var(--stat-bg);
  animation: fadeUp 0.5s 0.32s ease both;
  box-shadow: var(--shadow);
}
.stat-item {
  padding: 1.4rem 2.4rem; text-align: center;
  border-right: 1px solid var(--border); flex: 1;
  transition: background 0.2s;
}
.stat-item:last-child { border-right: none; }
.stat-item:hover { background: var(--card); }
.stat-num {
  font-family: 'EB Garamond', serif; font-size: 2rem;
  font-weight: 700; color: var(--text-heading); display: block;
}
.stat-num span { color: var(--accent); }
.stat-label { font-size: 0.68rem; color: var(--muted); text-transform: uppercase; letter-spacing: 0.12em; margin-top: 0.2rem; }

@keyframes fadeUp {
  from { opacity: 0; transform: translateY(18px); }
  to   { opacity: 1; transform: translateY(0); }
}

/* SECTIONS */
.section { position: relative; z-index: 2; padding: 6rem 2rem; max-width: 1100px; margin: 0 auto; }
.section-label { text-align: center; font-size: 0.68rem; letter-spacing: 0.22em; text-transform: uppercase; color: var(--accent); font-weight: 600; margin-bottom: 0.7rem; }
.section-title { font-family: 'EB Garamond', serif; font-size: clamp(1.8rem, 3vw, 2.6rem); font-weight: 600; text-align: center; margin-bottom: 1rem; color: var(--text-heading); letter-spacing: -0.01em; }
.section-desc { text-align: center; color: var(--muted); font-size: 0.92rem; max-width: 480px; margin: 0 auto 3.5rem; line-height: 1.75; }

/* STEPS */
.steps-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 1.5rem; }
.step-card {
  background: var(--card); border: 1px solid var(--border);
  border-radius: 10px; padding: 2rem 1.5rem;
  position: relative; transition: border-color 0.3s, transform 0.3s, background 0.3s;
  overflow: hidden; box-shadow: var(--shadow);
}
.step-card::before {
  content: ''; position: absolute; top: 0; left: 0; right: 0; height: 2px;
  background: linear-gradient(90deg, var(--accent), var(--accent2));
  opacity: 0; transition: opacity 0.3s;
}
.step-card:hover { border-color: var(--border-glow); transform: translateY(-4px); background: var(--card-hover); }
.step-card:hover::before { opacity: 1; }
.step-num { font-family: 'EB Garamond', serif; font-size: 3.5rem; font-weight: 700; color: var(--border-glow); line-height: 1; margin-bottom: 0.8rem; letter-spacing: -0.04em; opacity: 0.7; }
.step-icon { width: 42px; height: 42px; border-radius: 8px; background: rgba(79,109,180,0.1); border: 1px solid rgba(79,109,180,0.2); display: flex; align-items: center; justify-content: center; margin-bottom: 1rem; font-size: 1.2rem; }
.step-card h3 { font-family: 'EB Garamond', serif; font-size: 1.15rem; font-weight: 600; margin-bottom: 0.5rem; color: var(--text-heading); }
.step-card p { font-size: 0.82rem; color: var(--muted); line-height: 1.65; }

/* FEATURES */
.features-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 1.2rem; }
.feat-card {
  background: var(--card); border: 1px solid var(--border);
  border-radius: 10px; padding: 1.6rem;
  display: flex; gap: 1.2rem; align-items: flex-start;
  transition: border-color 0.3s, transform 0.2s, background 0.3s;
  box-shadow: var(--shadow);
}
.feat-card:hover { border-color: var(--border-glow); transform: translateY(-2px); background: var(--card-hover); }
.feat-icon { width: 46px; height: 46px; border-radius: 8px; display: flex; align-items: center; justify-content: center; font-size: 1.3rem; flex-shrink: 0; }
.feat-icon.purple { background: rgba(79,109,180,0.12); border: 1px solid rgba(79,109,180,0.22); }
.feat-icon.green  { background: rgba(52,180,130,0.1);   border: 1px solid rgba(52,180,130,0.2); }
.feat-icon.amber  { background: rgba(200,155,40,0.1);   border: 1px solid rgba(200,155,40,0.2); }
.feat-icon.red    { background: rgba(200,70,70,0.1);    border: 1px solid rgba(200,70,70,0.18); }
.feat-icon.pink   { background: rgba(180,70,140,0.1);   border: 1px solid rgba(180,70,140,0.18); }
.feat-icon.teal   { background: rgba(20,150,150,0.1);   border: 1px solid rgba(20,150,150,0.18); }
.feat-text h4 { font-family: 'EB Garamond', serif; font-size: 1rem; font-weight: 600; margin-bottom: 0.35rem; color: var(--text-heading); }
.feat-text p  { font-size: 0.82rem; color: var(--muted); line-height: 1.6; }

/* ROLES */
.roles-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(260px, 1fr)); gap: 1.5rem; }
.role-card {
  background: var(--card); border: 1px solid var(--border);
  border-radius: 10px; padding: 2rem; text-align: center;
  transition: all 0.3s; box-shadow: var(--shadow);
}
.role-card:hover { border-color: var(--border-glow); transform: translateY(-4px); background: var(--card-hover); }
.role-avatar { width: 60px; height: 60px; border-radius: 50%; margin: 0 auto 1.2rem; display: flex; align-items: center; justify-content: center; font-size: 1.6rem; }
.role-avatar.s { background: rgba(79,109,180,0.12); border: 2px solid rgba(79,109,180,0.28); }
.role-avatar.a { background: rgba(180,60,60,0.1);   border: 2px solid rgba(180,60,60,0.22); }
.role-avatar.o { background: rgba(52,150,110,0.1);  border: 2px solid rgba(52,150,110,0.22); }
.role-card h3 { font-family: 'EB Garamond', serif; font-size: 1.25rem; font-weight: 600; margin-bottom: 0.35rem; color: var(--text-heading); }
.role-card .role-tag { font-size: 0.68rem; color: var(--muted); text-transform: uppercase; letter-spacing: 0.12em; margin-bottom: 1rem; }
.role-perms { list-style: none; text-align: left; display: flex; flex-direction: column; gap: 0.4rem; }
.role-perms li { font-size: 0.82rem; color: var(--muted); display: flex; align-items: center; gap: 0.5rem; }
.role-perms li::before { content: ''; width: 4px; height: 4px; border-radius: 50%; background: var(--accent3); flex-shrink: 0; }

/* DIVIDER */
.divider { position: relative; z-index: 2; height: 1px; background: var(--rule-color); max-width: 1100px; margin: 0 auto; }

/* CTA BANNER */
.cta-banner { position: relative; z-index: 2; margin: 4rem auto; max-width: 900px; padding: 0 2rem; }
.cta-inner {
  background: var(--cta-bg); border: 1px solid var(--cta-border);
  border-radius: 12px; padding: 3.5rem 3rem; text-align: center;
  position: relative; overflow: hidden; box-shadow: var(--shadow);
}
.cta-inner::before {
  content: ''; position: absolute;
  top: -50%; left: 50%; transform: translateX(-50%);
  width: 400px; height: 300px;
  background: radial-gradient(circle, rgba(79,109,180,0.1) 0%, transparent 70%);
}
.cta-inner h2 { font-family: 'EB Garamond', serif; font-size: 2.1rem; font-weight: 600; margin-bottom: 0.7rem; position: relative; color: var(--text-heading); }
.cta-inner p  { color: var(--muted); margin-bottom: 2rem; font-size: 0.92rem; position: relative; }

/* FOOTER */
.sgr-footer {
  position: relative; z-index: 2;
  border-top: 1px solid var(--border);
  padding: 1.8rem 3rem; display: flex;
  justify-content: space-between; align-items: center;
  flex-wrap: wrap; gap: 1rem;
  font-size: 0.76rem; color: var(--dim);
}

/* LOGIN PAGE */
.login-page {
  min-height: 100vh; display: flex;
  align-items: center; justify-content: center;
  padding: 2rem; position: relative;
}
.login-back {
  position: fixed; top: 1.5rem; left: 1.5rem; z-index: 200;
  background: var(--card); border: 1px solid var(--border);
  color: var(--muted); padding: 0.45rem 1rem; border-radius: 6px;
  font-size: 0.8rem; font-family: 'DM Sans', sans-serif;
  cursor: pointer; display: flex; align-items: center; gap: 0.4rem;
  transition: all 0.2s; box-shadow: var(--shadow);
}
.login-back:hover { color: var(--text); border-color: var(--border-glow); }

@keyframes scaleIn {
  from { opacity: 0; transform: scale(0.97) translateY(16px); }
  to   { opacity: 1; transform: scale(1) translateY(0); }
}
@keyframes blink {
  0%,100% { opacity:1; } 50% { opacity:0.3; }
}

.login-card {
  background: var(--card); border: 1px solid var(--border);
  border-radius: 16px; padding: 2.8rem 2.5rem;
  max-width: 420px; width: 100%;
  position: relative; z-index: 10;
  animation: scaleIn 0.4s ease both;
  box-shadow: var(--shadow);
}
.login-card::before {
  content: ''; position: absolute; inset: -1px;
  border-radius: 16px;
  background: linear-gradient(135deg, rgba(79,109,180,0.2), transparent 55%);
  z-index: -1; pointer-events: none;
}
.login-heading { font-family: 'EB Garamond', serif; font-size: 2rem; font-weight: 600; color: var(--text-heading); margin-bottom: 0.3rem; }
.login-subheading { font-size: 0.85rem; color: var(--muted); margin-bottom: 2rem; }
.form-group { margin-bottom: 1.2rem; }
.form-label { display: block; font-size: 0.68rem; font-weight: 600; letter-spacing: 0.12em; text-transform: uppercase; color: var(--muted); margin-bottom: 0.5rem; }
.input-wrap { position: relative; display: flex; align-items: center; }
.input-icon { position: absolute; left: 0.9rem; font-size: 1rem; pointer-events: none; opacity: 0.7; }
.form-input {
  width: 100%; padding: 0.75rem 1rem 0.75rem 2.6rem;
  background: var(--surface); border: 1px solid var(--border);
  border-radius: 8px; color: var(--text);
  font-family: 'DM Sans', sans-serif; font-size: 0.9rem;
  transition: border-color 0.2s, box-shadow 0.2s; outline: none;
}
.form-input::placeholder { color: var(--dim); }
.form-input:focus { border-color: var(--border-glow); box-shadow: 0 0 0 3px rgba(79,109,180,0.12); }
.pw-toggle { position: absolute; right: 0.9rem; cursor: pointer; background: none; border: none; color: var(--muted); font-size: 1rem; padding: 0; transition: color 0.2s; }
.pw-toggle:hover { color: var(--text); }
.btn-signin {
  width: 100%; padding: 0.82rem;
  background: linear-gradient(135deg, var(--accent) 0%, var(--accent2) 100%);
  color: #fff; border: none; border-radius: 8px;
  font-family: 'DM Sans', sans-serif; font-size: 0.95rem; font-weight: 600;
  cursor: pointer; transition: all 0.2s; margin-top: 0.4rem;
  display: flex; align-items: center; justify-content: center; gap: 0.5rem;
  letter-spacing: 0.02em; box-shadow: 0 4px 20px rgba(79,109,180,0.35);
}
.btn-signin:hover { opacity: 0.9; transform: translateY(-1px); box-shadow: 0 6px 28px rgba(79,109,180,0.5); }
.login-divider { display: flex; align-items: center; gap: 1rem; margin: 1.6rem 0 1.2rem; }
.login-divider::before, .login-divider::after { content: ''; flex: 1; height: 1px; background: var(--border); }
.login-divider span { font-size: 0.72rem; color: var(--dim); letter-spacing: 0.08em; white-space: nowrap; }
.quick-roles { display: flex; flex-direction: column; gap: 0.7rem; }
.role-btn {
  display: flex; align-items: center; gap: 0.9rem;
  padding: 0.75rem 1rem;
  background: var(--surface); border: 1px solid var(--border);
  border-radius: 10px; cursor: pointer; transition: all 0.2s;
  text-align: left; width: 100%;
}
.role-btn:hover { border-color: var(--border-glow); background: var(--card-hover); transform: translateX(2px); }
.role-btn-icon { width: 36px; height: 36px; border-radius: 9px; display: flex; align-items: center; justify-content: center; font-size: 1.1rem; flex-shrink: 0; }
.role-btn-icon.s { background: rgba(79,109,180,0.15); border: 1px solid rgba(79,109,180,0.25); }
.role-btn-icon.a { background: rgba(180,60,60,0.12);   border: 1px solid rgba(180,60,60,0.22); }
.role-btn-icon.o { background: rgba(52,150,110,0.12);  border: 1px solid rgba(52,150,110,0.22); }
.role-btn-text { flex: 1; }
.role-btn-name { font-family: 'EB Garamond', serif; font-size: 1rem; font-weight: 600; color: var(--text-heading); display: block; line-height: 1.2; }
.role-btn-desc { font-size: 0.75rem; color: var(--muted); }
.role-btn-arrow { color: var(--dim); font-size: 0.9rem; }

/* COMING SOON PAGE */
.coming-soon-page {
  min-height: 100vh; display: flex;
  align-items: center; justify-content: center;
  padding: 2rem; position: relative;
}
.soon-card {
  background: var(--card); border: 1px solid var(--border);
  border-radius: 16px; padding: 3.5rem 3rem;
  max-width: 460px; width: 100%; text-align: center;
  position: relative; z-index: 10;
  animation: scaleIn 0.4s ease both;
  box-shadow: var(--shadow);
}
.soon-card::before {
  content: ''; position: absolute; inset: -1px;
  border-radius: 16px;
  background: linear-gradient(135deg, rgba(79,109,180,0.22), transparent 55%);
  z-index: -1; pointer-events: none;
}
.soon-glyph {
  width: 68px; height: 68px; border-radius: 14px;
  background: rgba(79,109,180,0.12); border: 1px solid rgba(79,109,180,0.28);
  display: flex; align-items: center; justify-content: center;
  margin: 0 auto 1.4rem; font-size: 1.9rem;
  box-shadow: 0 0 28px rgba(79,109,180,0.2);
}
.soon-chip {
  display: inline-flex; align-items: center; gap: 0.4rem;
  background: rgba(200,155,40,0.1); border: 1px solid rgba(200,155,40,0.25);
  color: #c9a030; font-size: 0.68rem; font-weight: 600;
  letter-spacing: 0.12em; text-transform: uppercase;
  padding: 0.28rem 0.75rem; border-radius: 4px; margin-bottom: 1.2rem;
}
.chip-dot { width: 5px; height: 5px; border-radius: 50%; background: #c9a030; animation: blink 1.8s ease-in-out infinite; }
.soon-role-badge {
  display: inline-flex; align-items: center; gap: 0.5rem;
  background: rgba(79,109,180,0.1); border: 1px solid rgba(79,109,180,0.22);
  border-radius: 6px; padding: 0.3rem 0.8rem;
  font-size: 0.75rem; color: var(--accent2); font-weight: 600;
  letter-spacing: 0.06em; margin-bottom: 1rem;
}
.soon-card h2 { font-family: 'EB Garamond', serif; font-size: 1.85rem; font-weight: 600; margin-bottom: 0.6rem; line-height: 1.2; color: var(--text-heading); }
.soon-desc { color: var(--muted); font-size: 0.86rem; line-height: 1.75; margin-bottom: 1.8rem; }
.progress-bar { background: var(--border); border-radius: 100px; height: 3px; overflow: hidden; margin: 0 auto 1.6rem; width: 80%; }
.progress-fill {
  height: 100%; width: 60%;
  background: linear-gradient(90deg, var(--accent), var(--accent2));
  border-radius: 100px; animation: progMove 3s ease-in-out infinite alternate;
}
@keyframes progMove { from { width: 50%; } to { width: 75%; } }
.soon-features {
  list-style: none; display: flex; flex-direction: column; gap: 0.7rem;
  text-align: left; background: var(--surface);
  border: 1px solid var(--border); border-radius: 8px;
  padding: 1.1rem 1.3rem; margin-bottom: 1.8rem;
}
.soon-features li { font-size: 0.82rem; color: var(--muted); display: flex; align-items: center; gap: 0.6rem; }
.lf-icon { width: 22px; height: 22px; border-radius: 5px; background: rgba(79,109,180,0.12); display: flex; align-items: center; justify-content: center; font-size: 0.75rem; flex-shrink: 0; }
.back-btn-bottom {
  background: transparent; border: 1px solid var(--border);
  color: var(--muted); padding: 0.68rem 1.8rem; border-radius: 6px;
  font-family: 'DM Sans', sans-serif; font-size: 0.84rem;
  cursor: pointer; transition: all 0.2s; width: 100%;
}
.back-btn-bottom:hover { border-color: var(--border-glow); color: var(--text); }

/* RESPONSIVE */
@media (max-width: 700px) {
  .sgr-nav { padding: 0 1.2rem; }
  .nav-links, .nav-divider, .nav-subtitle { display: none; }
  .hero { padding: 7rem 1.2rem 3rem; }
  .stats-bar { flex-wrap: wrap; border-radius: 8px; }
  .stat-item { border-right: none; border-bottom: 1px solid var(--border); }
  .stat-item:last-child { border-bottom: none; }
  .sgr-footer { flex-direction: column; text-align: center; padding: 1.5rem; }
  .cta-inner { padding: 2.5rem 1.5rem; }
  .login-card { padding: 2.5rem 1.5rem; }
}
`;

/* ─── SVG ICONS ─────────────────────────────────────────── */
const IconLayers = () => (
  <svg viewBox="0 0 24 24">
    <path d="M12 2L2 7l10 5 10-5-10-5z"/>
    <path d="M2 17l10 5 10-5"/>
    <path d="M2 12l10 5 10-5"/>
  </svg>
);
const IconLogin = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
    <path d="M15 3h4a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-4"/>
    <polyline points="10 17 15 12 10 7"/>
    <line x1="15" y1="12" x2="3" y2="12"/>
  </svg>
);
const IconBack = () => (
  <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
    <polyline points="15 18 9 12 15 6"/>
  </svg>
);
const IconMoon = () => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
    <path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/>
  </svg>
);
const IconSun = () => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
    <circle cx="12" cy="12" r="5"/>
    <line x1="12" y1="1" x2="12" y2="3"/>
    <line x1="12" y1="21" x2="12" y2="23"/>
    <line x1="4.22" y1="4.22" x2="5.64" y2="5.64"/>
    <line x1="18.36" y1="18.36" x2="19.78" y2="19.78"/>
    <line x1="1" y1="12" x2="3" y2="12"/>
    <line x1="21" y1="12" x2="23" y2="12"/>
    <line x1="4.22" y1="19.78" x2="5.64" y2="18.36"/>
    <line x1="18.36" y1="5.64" x2="19.78" y2="4.22"/>
  </svg>
);

/* ─── NAV ───────────────────────────────────────────────── */
function Nav({ theme, toggleTheme, showLogin, scrollToFeatures }) {
  return (
    <nav className="sgr-nav">
      <div className="nav-left">
        <span className="nav-brand">
          <div className="brand-emblem"><IconLayers /></div>
          SGR Portal
        </span>
        <div className="nav-divider" />
        <span className="nav-subtitle">Grievance Redressal System</span>
      </div>

      <ul className="nav-links">
        <li><a onClick={scrollToFeatures}>Features</a></li>
        <li><a href="#how">How it works</a></li>
        <li><a href="#roles">Roles</a></li>
      </ul>

      <div className="nav-right">
        <button className="theme-toggle" onClick={toggleTheme} title="Toggle theme" aria-label="Toggle theme">
          <div className={`theme-toggle-knob${theme === "light" ? " light" : ""}`}>
            {theme === "dark" ? <IconMoon /> : <IconSun />}
          </div>
        </button>
        <button className="btn-nav" onClick={showLogin}>Login →</button>
      </div>
    </nav>
  );
}

/* ─── HOME PAGE ─────────────────────────────────────────── */
function HomePage({ showLogin }) {
  const scrollTo = (id) => document.getElementById(id)?.scrollIntoView({ behavior: "smooth" });

  return (
    <div>
      <section className="hero">
        <h1 className="hero-title">
          Student Grievance<br />
          <span className="highlight">Redressal Portal</span>
        </h1>
        <p className="hero-sub">
          A transparent, role-based platform to raise, track, and resolve academic
          and administrative concerns — with real-time updates and escalation workflows.
        </p>
        <div className="hero-cta">
          <button className="btn-primary" onClick={showLogin}>
            <IconLogin /> Login to Portal
          </button>
          <button className="btn-outline" onClick={() => scrollTo("features")}>
            Explore Features ↓
          </button>
        </div>
        <div className="stats-bar">
          <div className="stat-item"><span className="stat-num">5<span>+</span></span><div className="stat-label">Categories</div></div>
          <div className="stat-item"><span className="stat-num">3</span><div className="stat-label">Escalation Levels</div></div>
          <div className="stat-item"><span className="stat-num">3</span><div className="stat-label">User Roles</div></div>
          <div className="stat-item"><span className="stat-num">12<span>+</span></span><div className="stat-label">Modules</div></div>
        </div>
      </section>

      <div className="divider" />

      {/* HOW IT WORKS */}
      <section className="section" id="how">
        <div className="section-label">How it works</div>
        <h2 className="section-title">Resolve grievances in 4 steps</h2>
        <p className="section-desc">From submission to resolution — every step is transparent and trackable.</p>
        <div className="steps-grid">
          {[
            { num: "01", icon: "📝", title: "Submit", desc: "Fill the 2-step form with your category, sub-category, priority, and description. Anonymous mode available." },
            { num: "02", icon: "🎫", title: "Get a Token", desc: "Receive a unique token ID instantly after submission. Use it anytime to check your grievance status." },
            { num: "03", icon: "⚙️", title: "Admin Reviews", desc: "Admin assigns the grievance to an officer. If unresolved, it escalates automatically up to 3 levels." },
            { num: "04", icon: "✅", title: "Resolution", desc: "A resolution note is added. Track the full timeline, export history as CSV, and view audit trails." },
          ].map((s) => (
            <div className="step-card" key={s.num}>
              <div className="step-num">{s.num}</div>
              <div className="step-icon">{s.icon}</div>
              <h3>{s.title}</h3>
              <p>{s.desc}</p>
            </div>
          ))}
        </div>
      </section>

      <div className="divider" />

      {/* FEATURES */}
      <section className="section" id="features">
        <div className="section-label">Platform Features</div>
        <h2 className="section-title">Everything you need</h2>
        <p className="section-desc">12+ modules built for students, admins, and officers — all in one portal.</p>
        <div className="features-grid">
          {[
            { color: "purple", icon: "📋", title: "Multi-step Grievance Form", desc: "Category, sub-category, priority level, description — with an anonymous submission toggle." },
            { color: "green",  icon: "🔍", title: "Token-based Status Tracker", desc: "Paste your unique token ID to get real-time status updates and a full resolution timeline." },
            { color: "amber",  icon: "⚖️", title: "3-Level Escalation", desc: "Grievances auto-escalate if unresolved. Admins can manually escalate with a single click." },
            { color: "red",    icon: "👮", title: "Officer Assignment", desc: "Admins assign grievances to specific officers who are responsible for resolution." },
            { color: "pink",   icon: "📊", title: "Admin Analytics Dashboard", desc: "Bar charts, resolution rates, and category-wise breakdowns for system-wide insights." },
            { color: "teal",   icon: "📤", title: "CSV Export", desc: "Students and admins can export grievance history as CSV for records and reporting." },
            { color: "purple", icon: "🔐", title: "Role-based Auth", desc: "Separate dashboards and access controls for Student, Admin, and Officer roles." },
            { color: "green",  icon: "🕵️", title: "Anonymous Mode", desc: "Students can hide their identity while still getting their grievance tracked and resolved." },
            { color: "amber",  icon: "📜", title: "Filterable History", desc: "View all past grievances filtered by status, category, or priority with sort options." },
          ].map((f) => (
            <div className="feat-card" key={f.title}>
              <div className={`feat-icon ${f.color}`}>{f.icon}</div>
              <div className="feat-text"><h4>{f.title}</h4><p>{f.desc}</p></div>
            </div>
          ))}
        </div>
      </section>

      <div className="divider" />

      {/* ROLES */}
      <section className="section" id="roles">
        <div className="section-label">User Roles</div>
        <h2 className="section-title">Built for everyone</h2>
        <p className="section-desc">Three distinct roles, each with a tailored dashboard and access level.</p>
        <div className="roles-grid">
          <div className="role-card">
            <div className="role-avatar s">🎓</div>
            <h3>Student</h3>
            <div className="role-tag">Default role</div>
            <ul className="role-perms">
              <li>Submit grievances with category &amp; priority</li>
              <li>Track status using token ID</li>
              <li>View personal history &amp; timeline</li>
              <li>Export own grievances as CSV</li>
              <li>Toggle anonymous mode</li>
            </ul>
          </div>
          <div className="role-card">
            <div className="role-avatar a">🛡️</div>
            <h3>Admin</h3>
            <div className="role-tag">Full access</div>
            <ul className="role-perms">
              <li>View &amp; manage all grievances</li>
              <li>Assign grievances to officers</li>
              <li>Escalate to Level 2 or Level 3</li>
              <li>Add resolution notes</li>
              <li>Access analytics dashboard</li>
              <li>Export all records as CSV</li>
            </ul>
          </div>
          <div className="role-card">
            <div className="role-avatar o">⚙️</div>
            <h3>Officer</h3>
            <div className="role-tag">Assigned handler</div>
            <ul className="role-perms">
              <li>View assigned grievances</li>
              <li>Update status and add notes</li>
              <li>Access admin panel view</li>
              <li>Communicate resolution details</li>
            </ul>
          </div>
        </div>
      </section>

      {/* CTA */}
      <div className="cta-banner">
        <div className="cta-inner">
          <h2>Ready to raise your voice?</h2>
          <p>Login with your student or admin credentials to get started.</p>
          <button className="btn-primary" onClick={showLogin}>
            <IconLogin /> Login to Portal
          </button>
        </div>
      </div>

      <footer className="sgr-footer">
        <div>Burla Vida Swetha &amp; Param Manasvi</div>
      </footer>
    </div>
  );
}

/* ─── LOGIN PAGE ────────────────────────────────────────── */
function LoginPage({ showHome, showComingSoon }) {
  const [pwVisible, setPwVisible] = useState(false);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  return (
    <div className="login-page">
      <button className="login-back" onClick={showHome}>
        <IconBack /> Back
      </button>

      <div className="login-card">
        <h2 className="login-heading">Welcome back</h2>
        <p className="login-subheading">Sign in to your account</p>

        <div className="form-group">
          <label className="form-label">Email Address</label>
          <div className="input-wrap">
            <span className="input-icon">✉️</span>
            <input
              className="form-input"
              type="email"
              placeholder="you@college.edu"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
            />
          </div>
        </div>

        <div className="form-group">
          <label className="form-label">Password</label>
          <div className="input-wrap">
            <span className="input-icon">🔑</span>
            <input
              className="form-input"
              type={pwVisible ? "text" : "password"}
              placeholder="••••••••"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
            />
            <button className="pw-toggle" type="button" onClick={() => setPwVisible((v) => !v)}>
              {pwVisible ? "🙈" : "👁"}
            </button>
          </div>
        </div>

        <button className="btn-signin" onClick={() => showComingSoon("credentials")}>
          Sign in &nbsp;→
        </button>

        <div className="login-divider"><span>Quick Demo Access</span></div>

        <div className="quick-roles">
          {[
            { key: "Student", cls: "s", icon: "🎓", name: "Student", desc: "Submit & track grievances" },
            { key: "Admin",   cls: "a", icon: "🛡️", name: "Admin",   desc: "Full system access" },
            { key: "Officer", cls: "o", icon: "⚙️", name: "Officer", desc: "Review & resolve cases" },
          ].map((r) => (
            <button className="role-btn" key={r.key} onClick={() => showComingSoon(r.key)}>
              <div className={`role-btn-icon ${r.cls}`}>{r.icon}</div>
              <div className="role-btn-text">
                <span className="role-btn-name">{r.name}</span>
                <span className="role-btn-desc">{r.desc}</span>
              </div>
              <span className="role-btn-arrow">›</span>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}

/* ─── COMING SOON PAGE ──────────────────────────────────── */
function ComingSoonPage({ showHome, showLogin, roleKey }) {
  const config = roleConfig[roleKey] || roleConfig.credentials;
  return (
    <div className="coming-soon-page">
      <button className="login-back" onClick={showLogin}>
        <IconBack /> Back
      </button>

      <div className="soon-card">
        <div className="soon-glyph">🔐</div>
        <div className="soon-chip"><div className="chip-dot" />Under Development</div>
        <div className="soon-role-badge">{config.badge}</div>
        <h2>This Page Will Be Updated Soon</h2>
        <p className="soon-desc">
          The <em>{config.label}</em> dashboard with full role-based access
          is currently being developed and will be available shortly.
        </p>
        <div className="progress-bar"><div className="progress-fill" /></div>
        <ul className="soon-features">
          {config.features.map(([icon, text]) => (
            <li key={text}>
              <div className="lf-icon">{icon}</div>
              {text}
            </li>
          ))}
        </ul>
        <button className="back-btn-bottom" onClick={showHome}>← Return to Home</button>
      </div>
    </div>
  );
}

/* ─── ROOT APP ──────────────────────────────────────────── */
export default function App() {
  const [theme, setTheme] = useState("dark");
  const [page, setPage] = useState("home");          // "home" | "login" | "soon"
  const [soonRole, setSoonRole] = useState("credentials");

  const toggleTheme = () => setTheme((t) => (t === "dark" ? "light" : "dark"));
  const showHome    = () => { setPage("home");  window.scrollTo(0, 0); };
  const showLogin   = () => { setPage("login"); window.scrollTo(0, 0); };
  const showComingSoon = (role) => { setSoonRole(role); setPage("soon"); window.scrollTo(0, 0); };

  /* inject CSS once */
  if (!document.getElementById("sgr-styles")) {
    const style = document.createElement("style");
    style.id = "sgr-styles";
    style.textContent = CSS;
    document.head.appendChild(style);
  }

  return (
    <div className="sgr-root" data-theme={theme}>
      <div className="bg-orbs">
        <div className="orb orb-1" />
        <div className="orb orb-2" />
        <div className="orb orb-3" />
      </div>

      {page === "home" && (
        <>
          <Nav
            theme={theme}
            toggleTheme={toggleTheme}
            showLogin={showLogin}
            scrollToFeatures={() => document.getElementById("features")?.scrollIntoView({ behavior: "smooth" })}
          />
          <HomePage showLogin={showLogin} />
        </>
      )}

      {page === "login" && (
        <LoginPage showHome={showHome} showComingSoon={showComingSoon} />
      )}

      {page === "soon" && (
        <ComingSoonPage showHome={showHome} showLogin={showLogin} roleKey={soonRole} />
      )}
    </div>
  );
}
